/* ===== Admin Dashboard logic ===== */
(function () {
  'use strict';
  const $ = s => document.querySelector(s);
  const $$ = s => Array.from(document.querySelectorAll(s));
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const rm = KS.rm;
  const AUTH = 'ks_admin_ok';
  let S = KS.settings(), PRD = KS.products(), TST = KS.testimonials();

  function toast(msg) { const t = $('#aToast'); t.textContent = msg || '✅ Disimpan!'; t.classList.add('show'); setTimeout(() => t.classList.remove('show'), 2200); }
  function saveS() { KS.saveSettings(S); }
  function saveP() { KS.saveProducts(PRD); }
  function saveT() { KS.saveTestimonials(TST); }

  /* ---------- image upload → compressed dataURL ---------- */
  function uploadImage(file, maxW, cb) {
    const im = new Image(); const rd = new FileReader();
    rd.onload = e => { im.onload = () => {
      const c = document.createElement('canvas'); const r = Math.min(1, maxW / im.width);
      c.width = im.width * r; c.height = im.height * r;
      c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      cb(c.toDataURL('image/webp', 0.86));
    }; im.src = e.target.result; };
    rd.readAsDataURL(file);
  }

  /* ================= VIEW: DASHBOARD ================= */
  function vDash() {
    const O = KS.orders();
    const today = new Date().toDateString();
    const todayO = O.filter(o => new Date(o.at).toDateString() === today);
    const rev = O.reduce((s, o) => o.status !== 'BATAL' ? s + o.total : 0, 0);
    const baru = O.filter(o => o.status === 'BARU').length;
    $('#ordBadge').textContent = baru; $('#ordBadge').classList.toggle('hidden', !baru);
    return `
    <div class="statsg">
      <div class="stat"><span>🧾 Jumlah Pesanan</span><b>${O.length}</b><i>${todayO.length} hari ini</i></div>
      <div class="stat"><span>💰 Jumlah Jualan</span><b>${rm(rev)}</b><i>tidak termasuk batal</i></div>
      <div class="stat"><span>🔔 Pesanan BARU</span><b>${baru}</b><i>perlu tindakan</i></div>
      <div class="stat"><span>☕ Produk Aktif</span><b>${PRD.length}</b><i>${PRD.reduce((a, p) => a + p.stock, 0)} unit stok</i></div>
    </div>
    <div class="panel"><h2>⚡ Tindakan Pantas</h2><p class="sub">Jalan pintas ke tugas biasa</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="abtn" data-go="prod">☕ Kemaskini Harga Produk</button>
        <button class="abtn" data-go="pay">💳 Tukar QR Bayaran</button>
        <button class="abtn" data-go="order">🧾 Semak Pesanan</button>
        <button class="abtn" data-go="pop">🔔 Tetapan Popup</button>
        <button class="abtn gy" data-go="ads">📣 Setup Ads & Pixel</button>
      </div>
    </div>
    <div class="panel"><h2>🕒 5 Pesanan Terkini</h2>
      ${O.length ? `<div style="overflow-x:auto"><table class="ptable"><thead><tr><th>ID</th><th>Masa</th><th>Pelanggan</th><th>Pakej</th><th>Jumlah</th><th>Status</th></tr></thead><tbody>
        ${O.slice(0, 5).map(o => `<tr><td class="kbd">${esc(o.id)}</td><td>${new Date(o.at).toLocaleString('ms-MY')}</td><td>${esc(o.name)}<br><small class="mut">${esc(o.phone)}</small></td><td>${esc(o.pack)} ×${o.qty}</td><td><b>${rm(o.total)}</b></td><td><span class="badge ${o.status === 'BARU' ? 'b-r' : o.status === 'POS' ? 'b-w' : o.status === 'SELESAI' ? 'b-ok' : 'b-g'}">${o.status}</span></td></tr>`).join('')}
      </tbody></table></div>` : '<p class="mut">Belum ada pesanan. Pesanan dari borang sales page akan muncul di sini.</p>'}
    </div>
    <div class="panel"><h2>🩺 Status Integrasi</h2><p class="sub">Konfigurasi semasa kedai anda</p>
      <table class="ptable"><tbody>
      ${[
        ['WhatsApp Order', S.whatsapp && S.whatsapp.length > 8 ? '✅ ' + S.whatsapp : '⚠️ belum set'],
        ['QR Bayaran', S.qrImage ? '✅ dimuat naik' : '⚠️ belum dimuat naik'],
        ['Popup Social Proof', S.popups.socialProof ? '✅ ON' : '⛔ OFF'],
        ['Popup Testimoni', S.popups.testimonial ? '✅ ON' : '⛔ OFF'],
        ['Live Online Counter', S.popups.onlineCounter ? '✅ ON' : '⛔ OFF'],
        ['Exit-Intent Offer', S.popups.exitIntent ? '✅ ON (kod ' + esc(S.popups.exitDiscount) + ')' : '⛔ OFF'],
        ['Google AdSense', S.ads.adsenseClient ? '✅ ' + esc(S.ads.adsenseClient) : '—'],
        ['Google Ads/GTAg', S.ads.gtagId ? '✅ ' + esc(S.ads.gtagId) : '—'],
        ['Meta (FB) Pixel', S.ads.fbPixel ? '✅ ' + esc(S.ads.fbPixel) : '—'],
      ].map(r => `<tr><td style="width:40%"><b>${r[0]}</b></td><td>${r[1]}</td></tr>`).join('')}
      </tbody></table>
    </div>`;
  }

  /* ================= VIEW: PRODUK & HARGA ================= */
  function vProd() {
    return `<div class="panel"><h2>☕ Produk &amp; Harga</h2><p class="sub">Edit pakej jualan. Perubahan terus dipaparkan di sales page. Medan kosong gambar = guna lalai.</p>
      <div id="prodList">${PRD.map((p, i) => `
        <div class="prodrow" data-i="${i}">
          <div><img src="${esc(p.img)}" alt="" onerror="this.style.opacity=.3">
            <label class="abtn gy sm" style="margin-top:8px;cursor:pointer">📷 Tukar<input type="file" accept="image/*" class="pimgup hidden"></label>
          </div>
          <div class="frow">
            <div class="frow c3">
              <div class="field"><label>Nama Produk</label><input class="pname" value="${esc(p.name)}"></div>
              <div class="field"><label>Badge (ribbon)</label><input class="pbadge" value="${esc(p.badge)}"></div>
              <div class="field"><label>URL/Laluan Gambar</label><input class="pimg" value="${esc(p.img)}"></div>
            </div>
            <div class="frow c3">
              <div class="field"><label>Harga Jual (RM)</label><input class="pprice" type="number" step="0.1" min="0" value="${p.price}"></div>
              <div class="field"><label>Harga Asal/Line-strike (RM)</label><input class="pwas" type="number" step="0.1" min="0" value="${p.was}"></div>
              <div class="field"><label>Stok</label><input class="pstock" type="number" min="0" value="${p.stock}"></div>
            </div>
            <div class="field"><label>Ciri-ciri (1 baris = 1 ciri)</label><textarea class="pfeats" rows="4">${esc(p.feats.join('\n'))}</textarea></div>
            <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap">
              <label class="sw"><input type="checkbox" class="phot" ${p.hot ? 'checked' : ''}><i></i>Tandakan "PALING LARIS" (kad tengah besar + CTA merah)</label>
              <span style="flex:1"></span>
              <button class="abtn rd sm pdel">🗑️ Padam Produk</button>
            </div>
          </div>
        </div>`).join('')}
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:6px">
        <button class="abtn gy" id="pAdd">➕ Tambah Produk Baru</button>
        <button class="abtn" id="pSave">💾 Simpan Semua Produk</button>
      </div></div>`;
  }
  function bindProd() {
    $('#pAdd').onclick = () => {
      PRD.push({ id: 'p' + Date.now().toString(36), name: 'Produk Baru', img: 'assets/img/kopi-songkok-al-ambiak-20g-pek-baru.webp', price: 10, was: 20, badge: 'BARU', hot: false, stock: 10, feats: ['Ciri 1', 'Ciri 2'] });
      toast('➕ Produk ditambah'); render('prod', true);
    };
    $('#pSave').onclick = () => {
      $$('#prodList .prodrow').forEach((row, i) => {
        const g = c => row.querySelector('.' + c);
        PRD[i] = Object.assign(PRD[i], {
          name: g('pname').value.trim(), badge: g('pbadge').value.trim(), img: g('pimg').value.trim() || PRD[i].img,
          price: Math.max(0, +g('pprice').value || 0), was: Math.max(0, +g('pwas').value || 0),
          stock: Math.max(0, +g('pstock').value || 0), feats: g('pfeats').value.split('\n').map(s => s.trim()).filter(Boolean),
          hot: g('phot').checked
        });
      });
      saveP(); toast();
    };
    $$('#prodList .pdel').forEach(b => b.onclick = () => {
      const i = +b.closest('.prodrow').dataset.i;
      if (confirm('Padam "' + PRD[i].name + '"?')) { PRD.splice(i, 1); saveP(); render('prod', true); toast('🗑️ Dipadam'); }
    });
    $$('#prodList .pimgup').forEach(u => u.onchange = () => {
      const i = +u.closest('.prodrow').dataset.i; const f = u.files[0]; if (!f) return;
      uploadImage(f, 700, url => { PRD[i].img = url; u.closest('.prodrow').querySelector('.pimg').value = url.slice(0, 60) + '… (upload)'; u.closest('.prodrow').querySelector('img').src = url; toast('📷 Gambar siap — tekan Simpan'); });
    });
  }

  /* ================= VIEW: POSTAGE ================= */
  function vPost() {
    return `<div class="panel"><h2>📦 Kadar Postage</h2><p class="sub">Dicaj automatik di borang order mengikut negeri pembeli.</p>
      <div class="frow c3">
        <div class="field"><label>Semenanjung (RM)</label><input id="pSem" type="number" step="0.5" min="0" value="${S.postageSemenanjung}"></div>
        <div class="field"><label>Sabah / Sarawak / Labuan (RM)</label><input id="pSS" type="number" step="0.5" min="0" value="${S.postageSabahSarawak}"></div>
        <div class="field"><label>FREE Postage min belian Semenanjung (RM)</label><input id="pFree" type="number" step="1" min="0" value="${S.freeShippingMin}"></div>
      </div>
      <button class="abtn" id="postSave">💾 Simpan Postage</button></div>`;
  }
  function bindPost() {
    $('#postSave').onclick = () => { S.postageSemenanjung = +$('#pSem').value || 0; S.postageSabahSarawak = +$('#pSS').value || 0; S.freeShippingMin = +$('#pFree').value || 0; saveS(); toast(); };
  }

  /* ================= VIEW: BAYARAN QR ================= */
  function vPay() {
    return `<div class="panel"><h2>💳 Bayaran QR (DuitNow / Bank)</h2>
      <p class="sub">QR ini dipaparkan kepada pelanggan semasa checkout. Guna DuitNow QR perniagaan anda (Maybank/CIMB/TnG/dsb.). Upload dalam telefon pun boleh.</p>
      <div class="frow c2">
        <div>
          <div class="qrbox" style="border-color:#d7e2da;border-style:solid;background:#fbfdfa" id="qrPrev">
            ${S.qrImage ? `<img src="${S.qrImage}" style="max-width:230px;margin:auto;border-radius:10px">` : '<p class="mut" style="padding:44px 10px">Belum ada QR dimuat naik</p>'}
          </div>
          <div style="display:flex;gap:10px;flex-wrap:wrap">
            <label class="abtn" style="cursor:pointer">📤 Upload QR<input id="qrUp" type="file" accept="image/*" class="hidden"></label>
            ${S.qrImage ? '<button class="abtn rd" id="qrDel">🗑️ Buang QR</button>' : ''}
          </div>
        </div>
        <div>
          <div class="field"><label>Nota Panduan Bayaran (di bawah QR)</label><textarea id="payNoteInp" rows="4">${esc(S.payNote)}</textarea></div>
          <div class="field"><label>No. WhatsApp penerima resit (format 60xxxxx)</label><input id="payWa" value="${esc(S.whatsapp)}" inputmode="tel"></div>
          <button class="abtn" id="paySave">💾 Simpan Tetapan Bayaran</button>
        </div>
      </div></div>`;
  }
  function bindPay() {
    $('#paySave').onclick = () => { S.payNote = $('#payNoteInp').value.trim(); S.whatsapp = $('#payWa').value.replace(/[^\d]/g, ''); saveS(); toast(); };
    const up = $('#qrUp'); if (up) up.onchange = () => { const f = up.files[0]; if (!f) return; uploadImage(f, 820, url => { S.qrImage = url; saveS(); render('pay', true); toast('✅ QR disimpan'); }); };
    const del = $('#qrDel'); if (del) del.onclick = () => { if (confirm('Buang QR semasa?')) { S.qrImage = ''; saveS(); render('pay', true); } };
  }

  /* ================= VIEW: POPUP & SOCIAL PROOF ================= */
  function vPop() {
    const P = S.popups;
    const sw = (key, label, hint) => `<div style="display:flex;justify-content:space-between;gap:14px;align-items:center;padding:12px 0;border-bottom:1px solid #eef2ee">
      <div><b>${label}</b><br><small class="mut">${hint}</small></div>
      <label class="sw"><input type="checkbox" data-k="${key}" ${P[key] ? 'checked' : ''}><i></i></label></div>`;
    return `<div class="panel"><h2>🔔 Popup &amp; Social Proof</h2><p class="sub">Kawal semua elemen konversi di sales page.</p>
      ${sw('socialProof', 'Popup "Pembelian Terkini" (social proof)', 'Notifikasi kiri-bawah: "Ahmad dari KL baru order…"')}
      ${sw('testimonial', 'Popup Testimoni', 'Modal testimoni auto selesa 30 saat pelawat di laman')}
      ${sw('onlineCounter', 'Live "X orang sedang melihat"', 'Chip hijau di bar navigasi')}
      ${sw('exitIntent', 'Exit-Intent Popup + Kod Diskaun', 'Muncul bila kursor keluar / 55s — tawaran kod RM5')}
      <div class="frow c3" style="margin-top:14px">
        <div class="field"><label>Toast pertama selepas (saat)</label><input id="ppFirst" type="number" min="3" value="${S.popups.toastFirstDelay}"></div>
        <div class="field"><label>Ulang toast setiap (saat)</label><input id="ppEvery" type="number" min="8" value="${S.popups.toastEvery}"></div>
        <div class="field"><label>Popup testimoni selepas (saat)</label><input id="ppTDelay" type="number" min="10" value="${S.popups.testiDelay}"></div>
        <div class="field"><label>Kod diskaun exit-intent</label><input id="ppCode" value="${esc(S.popups.exitDiscount)}"></div>
        <div class="field"><label>Angka asas "sedang melihat"</label><input id="ppBase" type="number" min="5" value="${S.onlineBase}"></div>
        <div class="field"><label>Tempoh countdown promosi (jam)</label><input id="ppPromo" type="number" min="1" value="${S.promoEndsHours}"></div>
      </div>
      <button class="abtn" id="popSave">💾 Simpan Popup</button></div>`;
  }
  function bindPop() {
    $$('input[data-k]').forEach(c => c.onchange = () => { S.popups[c.dataset.k] = c.checked; saveS(); });
    $('#popSave').onclick = () => {
      S.popups.toastFirstDelay = +$('#ppFirst').value || 6; S.popups.toastEvery = +$('#ppEvery').value || 16;
      S.popups.testiDelay = +$('#ppTDelay').value || 30; S.popups.exitDiscount = $('#ppCode').value.trim() || 'POWER5';
      S.onlineBase = +$('#ppBase').value || 23; S.promoEndsHours = +$('#ppPromo').value || 8;
      localStorage.removeItem('ks_promo_end'); saveS(); toast();
    };
  }

  /* ================= VIEW: TESTIMONI ================= */
  function vTesti() {
    return `<div class="panel"><h2>💬 Testimoni Pelanggan</h2><p class="sub">Dipaparkan di "dinding testimoni" sales page &amp; popup testimoni. Tambah testimoni sebenar pelanggan anda.</p>
      <div id="tList">${TST.map((t, i) => `
        <div class="prodrow" style="grid-template-columns:1fr" data-i="${i}">
          <div class="frow c3">
            <div class="field"><label>Nama</label><input class="tname" value="${esc(t.name)}"></div>
            <div class="field"><label>Lokasi</label><input class="tloc" value="${esc(t.loc)}"></div>
            <div class="field"><label>Rating (1–5)</label><input class="tstars" type="number" min="1" max="5" step="0.5" value="${t.stars}"></div>
          </div>
          <div class="field"><label>Teks testimoni</label><textarea class="ttext" rows="2">${esc(t.text)}</textarea></div>
          <button class="abtn rd sm tdel">🗑️ Padam</button>
        </div>`).join('')}</div>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="abtn gy" id="tAdd">➕ Tambah Testimoni</button>
        <button class="abtn" id="tSave">💾 Simpan Testimoni</button>
      </div></div>`;
  }
  function bindTesti() {
    $('#tAdd').onclick = () => { TST.push({ name: 'Pelanggan', loc: 'Malaysia', stars: 5, text: 'Tulis testimoni di sini…' }); render('testi', true); };
    $('#tSave').onclick = () => {
      $$('#tList .prodrow').forEach((row, i) => {
        TST[i] = { name: row.querySelector('.tname').value.trim(), loc: row.querySelector('.tloc').value.trim(), stars: Math.min(5, Math.max(1, +row.querySelector('.tstars').value || 5)), text: row.querySelector('.ttext').value.trim() };
      });
      saveT(); toast();
    };
    $$('#tList .tdel').forEach(b => b.onclick = () => { const i = +b.closest('.prodrow').dataset.i; if (confirm('Padam testimoni ini?')) { TST.splice(i, 1); saveT(); render('testi', true); toast('🗑️ Dipadam'); } });
  }

  /* ================= VIEW: PESANAN ================= */
  function vOrder() {
    const O = KS.orders();
    if (!O.length) return `<div class="panel"><h2>🧾 Pesanan</h2><p class="sub">Belum ada pesanan. Setiap order yang dihantar dari borang sales page akan disimpan di sini automatik (termasuk nama, telefon, alamat, pakej & jumlah).</p></div>`;
    return `<div class="panel"><div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center">
      <div><h2>🧾 Pesanan (${O.length})</h2><p class="sub">Klik status untuk kemaskini. Export CSV untuk rekod/kurier.</p></div>
      <div style="display:flex;gap:8px"><button class="abtn gy" id="oCsv">⬇️ Export CSV</button><button class="abtn rd" id="oClear">🗑️ Kosongkan</button></div></div>
      <div style="overflow-x:auto"><table class="ptable"><thead><tr><th>ID / Masa</th><th>Pelanggan</th><th>Alamat</th><th>Pakej</th><th>Jumlah</th><th>Status</th><th></th></tr></thead><tbody>
      ${O.map((o, i) => `<tr>
        <td><span class="kbd">${esc(o.id)}</span><br><small class="mut">${new Date(o.at).toLocaleString('ms-MY')}</small></td>
        <td><b>${esc(o.name)}</b><br><a href="https://wa.me/${esc(o.phone.replace(/^0/, '6'))}" target="_blank" style="font-size:.8rem">💬 ${esc(o.phone)}</a></td>
        <td style="max-width:230px"><small>${esc(o.addr)}, ${esc(o.state)}</small></td>
        <td><small>${esc(o.pack)} ×${o.qty}</small></td><td><b>${rm(o.total)}</b></td>
        <td><select class="ost" data-i="${i}" style="border:1.5px solid #d7e2da;border-radius:9px;padding:7px 10px;font-weight:700">
          ${['BARU', 'BAYAR', 'POS', 'SELESAI', 'BATAL'].map(s => `<option ${o.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></td>
        <td><button class="abtn rd sm odel" data-i="${i}">✕</button></td></tr>`).join('')}
      </tbody></table></div></div>`;
  }
  function bindOrder() {
    $$('.ost').forEach(sel => sel.onchange = () => { const a = KS.orders(); a[+sel.dataset.i].status = sel.value; KS.saveOrders(a); toast('✅ Status: ' + sel.value); });
    $$('.odel').forEach(b => b.onclick = () => { const a = KS.orders(); if (confirm('Padam pesanan ' + a[+b.dataset.i].id + '?')) { a.splice(+b.dataset.i, 1); KS.saveOrders(a); render('order', true); } });
    const csv = $('#oCsv'); if (csv) csv.onclick = () => {
      const a = KS.orders(); const rows = [['id', 'masa', 'nama', 'telefon', 'alamat', 'negeri', 'pakej', 'qty', 'jumlah', 'status']].concat(a.map(o => [o.id, o.at, o.name, o.phone, o.addr, o.state, o.pack, o.qty, o.total, o.status]));
      const blob = new Blob(['﻿' + rows.map(r => r.map(x => '"' + String(x).replace(/"/g, '""') + '"').join(',')).join('\n')], { type: 'text/csv' });
      const u = URL.createObjectURL(blob); const l = document.createElement('a'); l.href = u; l.download = 'pesanan-kopi-songkok.csv'; l.click(); URL.revokeObjectURL(u);
    };
    const cl = $('#oClear'); if (cl) cl.onclick = () => { if (confirm('Padam SEMUA pesanan?')) { KS.saveOrders([]); render('order', true); } };
  }

  /* ================= VIEW: ADS & TRACKING ================= */
  function vAds() {
    const A = S.ads;
    const box = (title, body) => `<div class="panel"><h2>${title}</h2><p class="sub">${body.sub}</p>${body.html}</div>`;
    return `
    ${box('📢 Google AdSense', { sub: 'Paparan iklan di sales page (2 slot automatik). Dapatkan Client ID di akaun AdSense anda.', html: `
      <div class="frow c2"><div class="field"><label>AdSense Client ID (cth: ca-pub-1234567890)</label><input id="adClient" value="${esc(A.adsenseClient)}" placeholder="ca-pub-XXXXXXXX"></div>
      <div class="field"><label>Ad Unit Slot ID</label><input id="adSlot" value="${esc(A.adsenseSlot)}" placeholder="1234567890"></div></div>`})}
    ${box('🔵 Google Ads / Analytics (gtag)', { sub: 'Tag penukaran — event "purchase" dihantar automatik bila order disahkan.', html: `
      <div class="frow c2"><div class="field"><label>Measurement / Tag ID (cth: G-XXXX atau AW-XXXX)</label><input id="adGtag" value="${esc(A.gtagId)}" placeholder="AW-123456789"></div>
      <div class="field"><label>Conversion send_to (cth: AW-123/AbCdEf)</label><input id="adConv" value="${esc(A.googleAdsConv)}" placeholder="AW-123456789/AbCdEfGh"></div></div>`})}
    ${box('🟣 Meta (Facebook) Pixel', { sub: 'Event dihantar: PageView, ViewContent, AddToCart, InitiateCheckout & Purchase — untuk retargeting FB/IG Ads.', html: `
      <div class="field"><label>Pixel ID (cth: 1234567890123456)</label><input id="adPixel" value="${esc(A.fbPixel)}" placeholder="XXXXXXXXXXXXXXXX"></div>`})}
    <div class="panel"><button class="abtn" id="adsSave">💾 Simpan Ads & Tracking</button>
    <p class="mut" style="font-size:.78rem;margin-top:12px">⚠️ Untuk produk kategori ini, elakkan kata kunci seksual eksplisit dalam kempen (dasar Google & Meta). Sasarkan angle "tenaga & kecergasan harian" — lihat nota dalam research-ANALISA.md.</p></div>`;
  }
  function bindAds() {
    $('#adsSave').onclick = () => { S.ads = { adsenseClient: $('#adClient').value.trim(), adsenseSlot: $('#adSlot').value.trim(), gtagId: $('#adGtag').value.trim(), googleAdsConv: $('#adConv').value.trim(), fbPixel: $('#adPixel').value.trim() }; saveS(); toast(); };
  }

  /* ================= VIEW: TETAPAN ================= */
  function vSet() {
    return `<div class="panel"><h2>⚙️ Tetapan Kedai</h2><p class="sub">Maklumat asas & keselamatan.</p>
      <div class="frow c2">
        <div class="field"><label>Nama Kedai</label><input id="sName" value="${esc(S.storeName)}"></div>
        <div class="field"><label>Tagline</label><input id="sTag" value="${esc(S.tagline)}"></div>
        <div class="field"><label>No. WhatsApp Order (60xxxxxxxxx)</label><input id="sWa" value="${esc(S.whatsapp)}" inputmode="tel"></div>
        <div class="field"><label>Kata Laluan Admin Baru</label><input id="sPass" type="text" placeholder="biar kosong jika tak tukar"></div>
      </div>
      <button class="abtn" id="setSave">💾 Simpan Tetapan</button></div>
    <div class="panel"><h2>🗄️ Backup & Data</h2><p class="sub">Eksport/import seluruh konfigurasi (untuk pindah peranti/server) atau reset ke tetapan kilang.</p>
      <div style="display:flex;gap:10px;flex-wrap:wrap">
        <button class="abtn gy" id="bExp">⬇️ Export JSON</button>
        <label class="abtn gy" style="cursor:pointer">⬆️ Import JSON<input id="bImp" type="file" accept=".json" class="hidden"></label>
        <button class="abtn rd" id="bReset">↺ Reset Semua Ke Lalai</button>
      </div></div>`;
  }
  function bindSet() {
    $('#setSave').onclick = () => {
      S.storeName = $('#sName').value.trim() || S.storeName; S.tagline = $('#sTag').value.trim();
      S.whatsapp = $('#sWa').value.replace(/[^\d]/g, '') || S.whatsapp;
      const p = $('#sPass').value.trim(); if (p && p.length >= 4) { S.adminPass = p; toast('✅ Tetapan & kata laluan disimpan'); } else toast();
      saveS();
    };
    $('#bExp').onclick = () => {
      const data = { settings: KS.settings(), products: KS.products(), testimonials: KS.testimonials(), orders: KS.orders() };
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const u = URL.createObjectURL(blob); const l = document.createElement('a'); l.href = u; l.download = 'backup-kopi-songkok-store.json'; l.click(); URL.revokeObjectURL(u);
    };
    $('#bImp').onchange = e => {
      const f = e.target.files[0]; if (!f) return;
      const r = new FileReader();
      r.onload = () => { try { const d = JSON.parse(r.result);
        if (d.settings) KS.saveSettings(d.settings); if (d.products) KS.saveProducts(d.products);
        if (d.testimonials) KS.saveTestimonials(d.testimonials); if (d.orders) KS.saveOrders(d.orders);
        S = KS.settings(); PRD = KS.products(); TST = KS.testimonials(); toast('✅ Import berjaya'); render('set', true);
      } catch (x) { alert('Fail JSON tidak sah'); } };
      r.readAsText(f);
    };
    $('#bReset').onclick = () => { if (confirm('Reset SEMUA tetapan, produk, testimoni & pesanan ke lalai?')) { KS.resetAll(); localStorage.removeItem('ks_seed'); location.reload(); } };
  }

  /* ================= ROUTER ================= */
  const VIEWS = {
    dash: { t: '📊 Dashboard', r: vDash, b: null },
    prod: { t: '☕ Produk & Harga', r: vProd, b: bindProd },
    post: { t: '📦 Postage', r: vPost, b: bindPost },
    pay: { t: '💳 Bayaran QR', r: vPay, b: bindPay },
    pop: { t: '🔔 Popup & Social Proof', r: vPop, b: bindPop },
    testi: { t: '💬 Testimoni', r: vTesti, b: bindTesti },
    order: { t: '🧾 Pesanan', r: vOrder, b: bindOrder },
    ads: { t: '📣 Ads & Tracking', r: vAds, b: bindAds },
    set: { t: '⚙️ Tetapan', r: vSet, b: bindSet }
  };
  function render(view, keep) {
    $$('.anav[data-v]').forEach(n => n.classList.toggle('on', n.dataset.v === view));
    $('#vtitle').textContent = VIEWS[view].t;
    $('#view').innerHTML = VIEWS[view].r();
    if (VIEWS[view].b) VIEWS[view].b();
    $$('#view [data-go]').forEach(b => b.onclick = () => render(b.dataset.go));
    if (!keep) window.scrollTo(0, 0);
    $('#aside').classList.remove('open');
  }

  /* ---------- auth ---------- */
  function showApp() {
    $('#loginWrap').classList.add('hidden'); $('#aside').classList.remove('hidden'); $('#amain').classList.remove('hidden');
    render('dash');
  }
  $$('.anav[data-v]').forEach(n => n.onclick = () => render(n.dataset.v));
  $('#hamb').onclick = () => $('#aside').classList.toggle('open');
  $('#btnLogout').onclick = () => { sessionStorage.removeItem(AUTH); location.reload(); };
  $('#btnLogin').onclick = () => {
    if ($('#apass').value === KS.settings().adminPass) { sessionStorage.setItem(AUTH, '1'); showApp(); }
    else { $('#apass').style.outline = '2.5px solid #c62828'; $('#apass').value = ''; $('#apass').placeholder = '❌ Salah — cuba lagi'; }
  };
  $('#apass').addEventListener('keydown', e => { if (e.key === 'Enter') $('#btnLogin').click(); });
  if (sessionStorage.getItem(AUTH) === '1') showApp();
})();
