/* ===== Store data layer — shared by sales page & admin (localStorage) ===== */
window.KS = (function () {
  const K = { settings: 'ks_settings_v1', products: 'ks_products_v1', testi: 'ks_testimonials_v1', orders: 'ks_orders_v1', auth: 'ks_auth_v1' };

  const DEFAULTS = {
    settings: {
      storeName: 'Kopi Songkok Al-Ambiak™ Official',
      tagline: 'Original Direct Kilang — Bukan Tiruan',
      whatsapp: '60123456789',
      currency: 'RM',
      postageSemenanjung: 8,
      postageSabahSarawak: 15,
      freeShippingMin: 150,
      promoEndsHours: 14,               // countdown target (hrs from now on load)
      qrImage: '',                       // dataURL uploaded in admin
      payNote: 'DuitNow QR / QR Bank — selepas bayar, tekan butang WhatsApp & hantar resit.',
      onlineBase: 23,                    // base for "orang sedang melihat"
      adminPass: 'admin123',
      popups: { socialProof: true, testimonial: true, onlineCounter: true, exitIntent: true, toastFirstDelay: 6, toastEvery: 16, testiDelay: 30, exitDiscount: 'POWER5' },
      ads: { adsenseClient: '', adsenseSlot: '', gtagId: '', googleAdsConv: '', fbPixel: '' }
    },
    products: [
      { id: 'trial', name: 'TRIAL PACK — 5 Sachet (20g)', img: 'assets/img/kopi-songkok-al-ambiak-20g-pek-baru.webp', price: 39.9, was: 55, badge: 'SESUAI CUBA DULU', hot: false, stock: 48,
        feats: ['5 sachet kopi herba 20g', '1 sachet = 2–3 bancuhan', 'Pakej pos rahsia & kemas', 'Pos setiap hari bekerja'] },
      { id: 'box1', name: '1 BOX ORIGINAL — 20 Sachet + FREE 2 Sachet Madu', img: 'assets/img/kopi-panggung-al-ambiak-box-original.webp', price: 89, was: 140, badge: 'PALING LARIS 🔥', hot: true, stock: 26,
        feats: ['20 sachet (1 box/papan original)', 'FREE 2 sachet madu asli', 'Jimat RM51 dari harga biasa', 'Terus dari kilang — bukan tiruan', 'Pakej pos rahsia & kemas'] },
      { id: 'combo2', name: 'COMBO POWER — 2 BOX (40 Sachet)', img: 'assets/img/kopi-songkok-al-ambiak-2pack.webp', price: 159, was: 280, badge: 'JIMAT MAKSIMUM', hot: false, stock: 15,
        feats: ['2 box (40 sachet) original', 'FREE 4 sachet madu asli', 'FREE postage Semenanjung', 'Stok sebulan lebih', 'Pakej pos rahsia & kemas'] }
    ],
    testimonials: [
      { name: 'Zulkefli', loc: 'Johor Bahru, Johor', stars: 5, text: 'Dah banyak repeat order. Barang memang bagus, paket aman kemas. Penghantaran laju pakai kurier. Terbaik!' },
      { name: 'Hafizuddin', loc: 'Butterworth, Pulau Pinang', stars: 5, text: 'Seller yang dipercayai. Barang dah sampai, packing cukup kemas & mantap. Baru nak try — usaha dulu, yang penting original.' },
      { name: 'Along', loc: 'Sungai Petani, Kedah', stars: 5, text: 'Kesan pada saya — daya tahan badan bertambah walaupun tidur tak mencukupi. Kerja pagi hingga malam pun masih bertenaga.' },
      { name: 'Rosli', loc: 'Shah Alam, Selangor', stars: 5, text: 'Setengah sachet pun dah rasa kesannya. Jimat sebab 1 sachet boleh buat 2–3 kali bancuhan. Pahit tapi berbaloi.' },
      { name: 'Cikgu Rahman', loc: 'Kota Bharu, Kelantan', stars: 4.5, text: 'Pos sampai dalam 2 hari. Harga masuk akal berbanding tempat lain. Ini repeat order ketiga saya.' },
      { name: 'Amri', loc: 'Kuching, Sarawak', stars: 5, text: 'Fast delivery & customer support bagus, semua soalan dijawab pantas. Item exactly as requested. Recommended.' }
    ]
  };

  const BUYER_POOL = [
    ['Ahmad', 'Kuala Lumpur'], ['Faizal', 'Ipoh'], ['Syafiq', 'Seremban'], ['Mat Din', 'Kangar'], ['Nazri', 'Melaka'],
    ['Hakim', 'Kuantan'], ['Ishak', 'Alor Setar'], ['Ridzuan', 'Klang'], ['Zamri', 'Taiping'], ['Husin', 'Kuala Terengganu'],
    ['Azman', 'Muar'], ['Firdaus', 'Batu Pahat'], ['Lan', 'Segamat'], ['Pak Ngah', 'Jitra'], ['Wan Soleh', 'Pasir Mas']
  ];

  function read(k, fb) { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? fb : v; } catch (e) { return fb; } }
  function write(k, v) { localStorage.setItem(k, JSON.stringify(v)); }

  const api = {
    KEY: K, BUYER_POOL,
    settings() { return Object.assign(JSON.parse(JSON.stringify(DEFAULTS.settings)), read(K.settings, {})); },
    saveSettings(s) { write(K.settings, s); },
    products() { const p = read(K.products, null); return Array.isArray(p) && p.length ? p : JSON.parse(JSON.stringify(DEFAULTS.products)); },
    saveProducts(p) { write(K.products, p); },
    testimonials() { const t = read(K.testi, null); return Array.isArray(t) && t.length ? t : JSON.parse(JSON.stringify(DEFAULTS.testimonials)); },
    saveTestimonials(t) { write(K.testi, t); },
    orders() { return read(K.orders, []); },
    addOrder(o) { const a = api.orders(); a.unshift(o); write(K.orders, a); return o; },
    saveOrders(a) { write(K.orders, a); },
    resetAll() { Object.values(K).forEach(k => localStorage.removeItem(k)); },
    rm(n) { return api.settings().currency + ' ' + Number(n).toFixed(2); },
    firstRunSeedDone: read('ks_seed', false)
  };
  if (!api.firstRunSeedDone) { write(K.settings, DEFAULTS.settings); write(K.products, DEFAULTS.products); write(K.testi, DEFAULTS.testimonials); write('ks_seed', true); }
  return api;
})();
