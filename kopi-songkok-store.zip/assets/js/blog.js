/* ===== Blog/article shared logic (lean version of main.js) ===== */
(function () {
  'use strict';
  const S = KS.settings();
  const P = KS.products();
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /* Ads / tracking injection */
  (function () {
    const A = S.ads || {};
    if (A.adsenseClient) {
      const a = document.createElement('script'); a.async = true; a.crossOrigin = 'anonymous';
      a.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(A.adsenseClient);
      document.head.appendChild(a);
      $$('.adslot').forEach(el => {
        el.innerHTML = '<ins class="adsbygoogle" style="display:block" data-ad-format="auto" data-full-width-responsive="true" data-ad-client="' + esc(A.adsenseClient) + '" data-ad-slot="' + esc(A.adsenseSlot || '') + '"></ins>';
        try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {}
      });
    } else { $$('.adslot').forEach(el => el.innerHTML = '📢 RUANG IKLAN — AdSense<br><small>(aktif bila Client ID diisi dalam Admin)</small>'); }
    if (A.gtagId) {
      const g = document.createElement('script'); g.async = true;
      g.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(A.gtagId);
      document.head.appendChild(g);
      window.dataLayer = window.dataLayer || []; window.gtag = function () { window.dataLayer.push(arguments); };
      window.gtag('js', new Date()); window.gtag('config', A.gtagId);
    }
    if (A.fbPixel) {
      !function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments) }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s) }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
      window.fbq('init', A.fbPixel); window.fbq('track', 'PageView');
    }
  })();

  /* Countdown (promobar) */
  const cd = $('#cd');
  if (cd) {
    let end = Number(localStorage.getItem('ks_promo_end') || 0);
    if (!end || end < Date.now()) { end = Date.now() + (S.promoEndsHours || 8) * 3600e3; localStorage.setItem('ks_promo_end', end); }
    const tick = () => { let d = Math.max(0, end - Date.now()); const p = x => String(x).padStart(2, '0'); cd.textContent = p(Math.floor(d / 3600e3)) + ':' + p(Math.floor(d % 3600e3 / 6e4)) + ':' + p(Math.floor(d % 6e4 / 1e3)); };
    tick(); setInterval(tick, 1000);
  }

  /* Online chip */
  if (S.popups.onlineCounter) {
    const el = $('#onlineCount');
    if (el) { let n = S.onlineBase + Math.floor(Math.random() * 7); el.textContent = n; setInterval(() => { n += Math.random() > .45 ? 1 : -1; n = Math.max(8, Math.min(S.onlineBase + 18, n)); el.textContent = n; }, 8000); }
  } else { const o = $('#onlineChip'); if (o) o.style.display = 'none'; }

  /* WhatsApp links */
  $$('.js-wa').forEach(b => b.addEventListener('click', e => {
    e.preventDefault();
    const msg = encodeURIComponent('Assalamualaikum, saya baca blog Kopi Songkok Al-Ambiak dan nak tanya tentang produk. Masih ada stok?');
    window.open('https://wa.me/' + S.whatsapp + '?text=' + msg, '_blank');
  }));

  /* Reading progress bar */
  const pb = $('#prog');
  if (pb) {
    const art = $('.article') || document.body;
    const upd = () => {
      const r = art.getBoundingClientRect();
      const total = r.height - innerHeight;
      const done = Math.min(Math.max(-r.top, 0), Math.max(total, 1));
      pb.style.width = (done / Math.max(total, 1) * 100) + '%';
    };
    addEventListener('scroll', upd, { passive: true }); upd();
  }

  /* Social proof toast */
  if (S.popups.socialProof) {
    const el = $('#spToast');
    if (el) {
      const show = () => {
        const b = KS.BUYER_POOL[Math.floor(Math.random() * KS.BUYER_POOL.length)];
        const p = P[Math.floor(Math.random() * P.length)];
        const m = 2 + Math.floor(Math.random() * 28);
        el.innerHTML = '<div class="ava">' + esc(b[0][0]) + '</div><div><b>' + esc(b[0]) + ' dari ' + esc(b[1]) + '</b><p>baru sahaja order <b>' + esc(p.name.split('—')[0].trim()) + '</b> • ' + m + ' minit lalu</p></div><button class="tx" aria-label="tutup">✕</button>';
        el.classList.add('show');
        el.querySelector('.tx').onclick = () => el.classList.remove('show');
        setTimeout(() => el.classList.remove('show'), 6500);
      };
      setTimeout(show, (S.popups.toastFirstDelay || 6) * 1000);
      setInterval(show, Math.max(20, (S.popups.toastEvery || 16)) * 1000);
    }
  }

  /* Reveal on scroll */
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.style.opacity = 1; e.target.style.transform = 'none'; io.unobserve(e.target); } }), { threshold: .1 });
  $$('.rv').forEach(el => { el.style.cssText += 'opacity:0;transform:translateY(22px);transition:opacity .6s,transform .6s'; io.observe(el); });
})();
