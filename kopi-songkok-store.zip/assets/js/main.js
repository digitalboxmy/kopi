/* ===== Sales page logic ===== */
(function () {
  'use strict';
  const S = KS.settings();
  const P = KS.products();
  const T = KS.testimonials();
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const rm = KS.rm;

  /* ---------- Inject Ads / Tracking (only if configured in Admin) ---------- */
  (function tracking() {
    const A = S.ads || {};
    if (A.adsenseClient) {
      const a = document.createElement('script');
      a.async = true; a.crossOrigin = 'anonymous';
      a.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' + encodeURIComponent(A.adsenseClient);
      document.head.appendChild(a);
      $$('.adslot').forEach(el => {
        el.innerHTML = '<ins class="adsbygoogle" style="display:block" data-ad-format="auto" data-full-width-responsive="true" data-ad-client="' + esc(A.adsenseClient) + '" data-ad-slot="' + esc(A.adsenseSlot || '') + '"></ins>';
        try { (window.adsbygoogle = window.adsbygoogle || []).push({}); } catch (e) {}
      });
    } else {
      $$('.adslot').forEach(el => el.innerHTML = '📢 RUANG IKLAN — Google AdSense<br><small>(Aktif bila Client ID diisi dalam Admin Dashboard → Ads & Tracking)</small>');
    }
    if (A.gtagId) {
      const g = document.createElement('script'); g.async = true;
      g.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(A.gtagId);
      document.head.appendChild(g);
      window.dataLayer = window.dataLayer || []; window.gtag = function () { window.dataLayer.push(arguments); };
      window.gtag('js', new Date()); window.gtag('config', A.gtagId);
    }
    if (A.fbPixel) {
      !function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments) }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s) }(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
      window.fbq('init', A.fbPixel); window.fbq('track', 'PageView'); window.fbq('track', 'ViewContent', { content_name: 'Kopi Songkok Al-Ambiak' });
    }
  })();
  const fire = (gtagEv, fbEv, val) => {
    try { if (window.gtag && S.ads.gtagId) window.gtag('event', gtagEv, { value: val, currency: 'MYR' }); } catch (e) {}
    try { if (window.fbq && S.ads.fbPixel) window.fbq('track', fbEv, { value: val, currency: 'MYR' }); } catch (e) {}
    try { if (window.gtag && S.ads.googleAdsConv && gtagEv === 'purchase') window.gtag('event', 'conversion', { send_to: S.ads.googleAdsConv, value: val, currency: 'MYR' }); } catch (e) {}
  };

  /* ---------- Countdown ---------- */
  (function countdown() {
    const el = $('#cd'); if (!el) return;
    let end = Number(localStorage.getItem('ks_promo_end') || 0);
    if (!end || end < Date.now()) { end = Date.now() + (S.promoEndsHours || 8) * 3600e3; localStorage.setItem('ks_promo_end', end); }
    const tick = () => {
      let d = Math.max(0, end - Date.now());
      const h = Math.floor(d / 3600e3), m = Math.floor(d % 3600e3 / 6e4), s = Math.floor(d % 6e4 / 1e3);
      el.textContent = String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    };
    tick(); setInterval(tick, 1000);
  })();

  /* ---------- Online customer counter ---------- */
  if (S.popups.onlineCounter) {
    const el = $('#onlineCount'); if (el) {
      let n = S.onlineBase + Math.floor(Math.random() * 7);
      const upd = () => { el.textContent = n; n += Math.random() > 0.45 ? 1 : -1; n = Math.max(S.onlineBase - 6, Math.min(S.onlineBase + 18, n)); };
      upd(); setInterval(upd, 7000 + Math.random() * 5000);
    }
  } else { const o = $('#onlineChip'); if (o) o.style.display = 'none'; }

  /* ---------- Render: products / pricing / packages ---------- */
  function renderPricing() {
    const grid = $('#priceGrid'); if (!grid) return;
    grid.innerHTML = P.map(p => `
      <article class="pcard ${p.hot ? 'hot' : ''}">
        <div class="ptag">${esc(p.badge)}</div>
        <div class="pname">${esc(p.name)}</div>
        <div class="pimg"><img loading="lazy" src="${esc(p.img)}" alt="${esc(p.name)} — kopi songkok al-ambiak original"></div>
        <div class="pold">${rm(p.was)}</div>
        <div class="pnew">${rm(p.price)} <small>+pos</small></div>
        <div class="center"><span class="save">JIMAT ${rm(p.was - p.price)}</span></div>
        <ul class="pfeats">${p.feats.map(f => `<li>${esc(f)}</li>`).join('')}</ul>
        <a href="#order" class="btn ${p.hot ? 'btn-red pulse' : 'btn-p'}" data-pk="${esc(p.id)}">▶ PILIH PAKEJ INI</a>
      </article>`).join('');
    $$('#priceGrid [data-pk]').forEach(b => b.addEventListener('click', () => {
      const r = $('#pk-' + b.dataset.pk); if (r) { r.checked = true; r.closest('.pack-o').classList.add('active-glow'); setTimeout(() => r.closest('.pack-o').classList.remove('active-glow'), 1300); calc(); }
    }));
  }

  function renderPackOptions() {
    const w = $('#packSel'); if (!w) return;
    w.innerHTML = P.map((p, i) => `
      <label class="pack-o"><input type="radio" name="pk" id="pk-${esc(p.id)}" value="${esc(p.id)}" ${i === 1 ? 'checked' : ''}>
        <span class="pl"><b>${esc(p.name)}</b><span>Stok tinggal: ${p.stock}</span></span>
        <span class="pp">${rm(p.price)}<s>${rm(p.was)}</s></span>
      </label>`).join('');
    $$('input[name=pk]', w).forEach(r => r.addEventListener('change', calc));
  }

  function postageFor(state) {
    const e = ['Sabah', 'Sarawak', 'Labuan'];
    return e.includes(state) ? S.postageSabahSarawak : S.postageSemenanjung;
  }
  function cart() {
    const id = ($('input[name=pk]:checked') || {}).value; const p = P.find(x => x.id === id) || P[0];
    const qty = Math.max(1, Math.min(10, Number(($('#qty') || {}).value || 1)));
    const state = ($('#state') || {}).value || 'Selangor';
    const sub = p.price * qty;
    let pos = qty === 1 ? postageFor(state) : postageFor(state) + ((qty - 1) * 2);
    if (sub >= S.freeShippingMin && !['Sabah', 'Sarawak', 'Labuan'].includes(state)) pos = 0;
    return { p, qty, state, sub, pos, total: sub + pos };
  }
  function calc() {
    const c = cart();
    const set = (id, v) => { const e = $(id); if (e) e.textContent = v; };
    set('#tSub', rm(c.sub)); set('#tPos', c.pos === 0 ? 'FREE 🎉' : rm(c.pos)); set('#tTot', rm(c.total));
    set('#scPrice', rm(c.p.price));
    fire('select_item', 'AddToCart', c.sub);
    return c;
  }

  /* ---------- Testimonials wall ---------- */
  function starStr(n) { let s = ''; for (let i = 1; i <= 5; i++) s += i <= n ? '★' : (i - 0.5 <= n ? '⯨' : '☆'); return s; }
  function renderTesti() {
    const w = $('#testiWall'); if (!w) return;
    w.innerHTML = T.map(t => `
      <article class="tcard">
        <div class="hd"><div class="ava">${esc(t.name[0])}</div>
          <div class="who"><b>${esc(t.name)}</b><span>${esc(t.loc)} • <span class="stars">${starStr(t.stars)}</span></span></div>
        </div>
        <p>"${esc(t.text)}"</p><span class="vrf">✔ Pembeli Disahkan</span>
      </article>`).join('');
  }

  /* ---------- Social proof toast ---------- */
  function toastLoop() {
    if (!S.popups.socialProof) return;
    const el = $('#spToast'); if (!el) return;
    const show = () => {
      const b = KS.BUYER_POOL[Math.floor(Math.random() * KS.BUYER_POOL.length)];
      const p = P[Math.floor(Math.random() * P.length)];
      const m = 2 + Math.floor(Math.random() * 28);
      el.innerHTML = `<div class="ava">${esc(b[0][0])}</div>
        <div><b>${esc(b[0])} dari ${esc(b[1])}</b><p>baru sahaja order <b>${esc(p.name.split('—')[0].trim())}</b> • ${m} minit lalu</p></div>
        <button class="tx" aria-label="tutup">✕</button>`;
      el.classList.add('show');
      el.querySelector('.tx').onclick = () => el.classList.remove('show');
      setTimeout(() => el.classList.remove('show'), 6500);
    };
    setTimeout(show, (S.popups.toastFirstDelay || 6) * 1000);
    setInterval(show, (S.popups.toastEvery || 16) * 1000);
  }

  /* ---------- Testimonial popup + exit intent ---------- */
  let testiShown = false;
  function showTesti(force) {
    if (!S.popups.testimonial || (testiShown && !force)) return;
    testiShown = true;
    const t = T[Math.floor(Math.random() * T.length)];
    $('#tpBody').innerHTML = `<div class="stars">★★★★★</div>
      <p class="tp-txt">"${esc(t.text)}"</p>
      <div class="tp-who"><div class="ava">${esc(t.name[0])}</div>
      <div><b>${esc(t.name)}</b><br><small class="mut">${esc(t.loc)} • Pembeli Disahkan</small></div></div>`;
    $('#tModal').classList.add('open');
  }
  let exitShown = false;
  function exitIntent() {
    if (!S.popups.exitIntent) return;
    const pull = () => {
      if (exitShown || testiShown === false && document.hidden) return;
      if (exitShown) return;
      exitShown = true;
      $('#exCode').textContent = S.popups.exitDiscount || 'POWER5';
      $('#exModal').classList.add('open');
    };
    document.addEventListener('mouseout', e => { if (!e.relatedTarget && e.clientY < 8) pull(); });
    setTimeout(() => { if (!document.hidden) pull(); }, 55000); // mobile fallback timer
  }

  /* ---------- Checkout flow ---------- */
  function checkout() {
    const f = { name: $('#fName'), phone: $('#fPhone'), addr: $('#fAddr') };
    let ok = true;
    Object.values(f).forEach(i => { i.style.outline = ''; if (!String(i.value).trim()) { i.style.outline = '2.5px solid #c62828'; ok = false; } });
    const ph = f.phone.value.replace(/[^0-9]/g, '');
    if (ok && ph.length < 9) { f.phone.style.outline = '2.5px solid #c62828'; ok = false; }
    if (!ok) { toastMsg('⚠️ Sila lengkapkan nama, telefon & alamat'); return; }
    const c = calc();
    window._order = { c, name: f.name.value.trim(), phone: ph, addr: f.addr.value.trim() };
    const qrWrap = $('#qrWrap');
    qrWrap.innerHTML = S.qrImage
      ? `<img src="${S.qrImage}" alt="QR Bayaran DuitNow" ><p class="mut" style="font-size:.8rem;margin-top:8px">Imbas dengan mana-mana aplikasi bank / e-wallet</p>`
      : `<div class="qrph"><span>⚠️ QR bayaran belum dimuat naik.<br>Admin → Bayaran QR → Upload<br><small>(DuitNow QR / QR bank anda)</small></span></div>`;
    $('#qrTotal').textContent = rm(c.total);
    $('#payNote').textContent = S.payNote;
    fire('begin_checkout', 'InitiateCheckout', c.total);
    $('#qrModal').classList.add('open');
  }

  function confirmPayment() {
    const o = window._order; if (!o) return;
    const id = 'KS' + Date.now().toString(36).toUpperCase();
    KS.addOrder({ id, at: new Date().toISOString(), name: o.name, phone: o.phone, addr: o.addr, state: o.c.state, pack: o.c.p.name, qty: o.c.qty, total: o.c.total, status: 'BARU' });
    fire('purchase', 'Purchase', o.c.total);
    $('#qrModal').classList.remove('open');
    $('#okId').textContent = id;
    const msg = encodeURIComponent(`Assalamualaikum, saya ${o.name} (${id}). Saya telah buat bayaran untuk ${o.c.p.name} x${o.c.qty} (${rm(o.c.total)}). Alamat: ${o.addr}, ${o.c.state}. Berikut resit bayaran saya:`);
    $('#okWa').href = `https://wa.me/${S.whatsapp}?text=${msg}`;
    $('#okModal').classList.add('open');
  }
  function openWa(e) {
    e.preventDefault();
    const c = cart();
    const msg = encodeURIComponent(`Assalamualaikum, saya nak tanya/order ${c.p.name} (${rm(c.p.price)}). Masih ada stok?`);
    window.open(`https://wa.me/${S.whatsapp}?text=${msg}`, '_blank');
  }

  let tmrT;
  function toastMsg(m) {
    let t = $('#miniToast');
    if (!t) { t = document.createElement('div'); t.id = 'miniToast'; t.className = 'toastok'; document.body.appendChild(t); }
    t.textContent = m; t.classList.add('show'); clearTimeout(tmrT); tmrT = setTimeout(() => t.classList.remove('show'), 3200);
  }

  /* ---------- Reveal on scroll ---------- */
  function reveal() {
    const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.style.opacity = 1; e.target.style.transform = 'none'; io.unobserve(e.target); } }), { threshold: .12 });
    $$('.rv').forEach(el => { el.style.cssText += 'opacity:0;transform:translateY(22px);transition:opacity .6s,transform .6s'; io.observe(el); });
  }

  /* ---------- Wire up ---------- */
  document.addEventListener('DOMContentLoaded', () => {
    document.title = document.title.replace('{STORE}', S.storeName);
    $$('.js-wa').forEach(b => b.addEventListener('click', openWa));
    const b = $('#btnOrder'); if (b) b.addEventListener('click', checkout);
    const q = $('#qty'); if (q) q.addEventListener('input', calc);
    const st = $('#state'); if (st) st.addEventListener('change', calc);
    const cp = $('#btnPaid'); if (cp) cp.addEventListener('click', confirmPayment);
    $$('[data-close]').forEach(x => x.addEventListener('click', () => x.closest('.modal').classList.remove('open')));
    $$('.modal').forEach(m => m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); }));
    $$('.copy-code').forEach(x => x.addEventListener('click', () => { navigator.clipboard && navigator.clipboard.writeText(x.textContent.trim()); toastMsg('✅ Kod disalin: ' + x.textContent.trim()); }));
    const tt = $('#btnTpCta'); if (tt) tt.addEventListener('click', () => { $('#tModal').classList.remove('open'); });
    renderPricing(); renderPackOptions(); renderTesti(); calc(); reveal(); toastLoop(); exitIntent();
    setTimeout(showTesti, (S.popups.testiDelay || 30) * 1000);
    document.dispatchEvent(new CustomEvent('ks:ready'));
  });
})();
